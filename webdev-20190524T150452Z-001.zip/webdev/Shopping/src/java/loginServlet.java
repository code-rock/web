import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class loginServlet extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException,IOException {
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        String name = req.getParameter("userid");
        String pass = req.getParameter("password");
        
//        pw.println("Name is : " + name);
//        pw.println("Password is : " + pass);
        
        try {
            // register the driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            // create connetion
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/users","userinfo","userinfo");
            
            PreparedStatement ps = con.prepareStatement("select * from users where userid=? and password=?");
            ps.setString(1, name);
            ps.setString(2, pass);
            
            ResultSet queryList = ps.executeQuery();
            if (queryList.next()) {
                pw.println("You have successfully logged in\n");
                pw.println(queryList.getString("uname"));
                ps = con.prepareStatement("insert into active values(?)");
                ps.setString(1,name);
                ps.executeUpdate();
                res.sendRedirect("homepage.jsp");
            }
            else {
                pw.println("<meta http-equiv='refresh' content='3;URL=homepage.jsp'>");//redirects after 3 seconds
                pw.println("<p style='color:red;'>Either username or password is incorrect.</p>");
                pw.println("<p style='color:green;'>You are being redirected to Signup Page.</p>");
            }
            
        } catch (Exception e) {
            System.out.println(e);
            pw.println(e);
        }
        
        pw.close();
    }
}