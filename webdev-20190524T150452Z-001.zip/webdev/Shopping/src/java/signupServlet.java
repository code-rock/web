import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class signupServlet extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException,IOException {
        res.setContentType("text/html");
        PrintWriter pw = res.getWriter();
        String userid = req.getParameter("userid");
        String name = req.getParameter("uname");
        String pass = req.getParameter("password");
        String email = req.getParameter("email");
        String contact = req.getParameter("contact");
        String address = req.getParameter("address");
        String pincode = req.getParameter("pincode");
        
//        pw.println("Name is : " + name);
//        pw.println("Password is : " + pass);
        
        try {
            // register the driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            // create connetion
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/users","userinfo","userinfo");
            
            PreparedStatement ps = con.prepareStatement("insert into users values(?,?,?,?,?,?,?)");
            ps.setString(1, userid);
            ps.setString(2, name);
            ps.setString(3, pass);
            ps.setString(4, email);
            ps.setString(5, contact);
            ps.setString(6, address);
            ps.setString(7, pincode);
            
            int j = ps.executeUpdate();
            if (j > 0) 
                pw.println("You have successfully Signed up");
            
            ps = con.prepareStatement("insert into active values(?)");
            ps.setString(1, userid);
            j = ps.executeUpdate();
            if (j > 0) {
                res.sendRedirect("homepage.jsp");
            }
            
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        pw.close();
    }
}